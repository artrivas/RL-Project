# Entrega final · DS5345 P2 Vía B

- `informe.pdf`: análisis del simulador anclado en M5.
- `diapositivas.pdf` y `guion.md`: sustentación en dos partes.
- `video.mp4`: comparación sincronizada de las tres políticas, 586, semilla 0.
- `resultados.csv`: resultados por condición y semilla; la ingenua es determinista y se lista una vez por variante.
- `fuentes/`: fuentes LaTeX editables, con el gráfico requerido por el informe.
- `SHA256SUMS.txt`: huellas de los archivos del paquete.

`m1` mantiene el precio histórico del día; `orig` permite multiplicadores dinámicos. Los quiebres, pedidos y retornos son simulados, no históricos de Walmart.

Para reconstruir los documentos, ejecutar `tectonic informe.tex` dentro de `fuentes/informe/` y `tectonic presentacion_p2.tex` dentro de `fuentes/diapositivas/`. En la exposición, abrir `video.mp4` al llegar a la diapositiva de demostración.
