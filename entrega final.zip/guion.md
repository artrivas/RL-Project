# Guion breve por diapositiva (20 min, dos mitades)

Total: bloque 1 $\approx$ 9 min (slides 1-6), bloque 2 $\approx$ 11 min con demo (slides 7-11).
Hablar suelto; en pantalla nunca hay parrafos, solo el guion los explica.
Solo se comparan tres brazos: T0 cooperativo, E egoista y N ingenuo.

## 1. Portada (1:00)
Tres tiendas que reponen desde un almacen comun. Pregunta: puede el refuerzo pedir y poner precio mejor que una heuristica ingenua. Todo ocurre en un simulador anclado en M5; el resto es simulado.

## 2. Portadilla I (0:20)
Primera mitad: que decide cada tienda, como fluye el inventario, que parte es M5 real y que parte es supuesta, y la escalera de metodos.

## 3. Que ve y decide (2:30)
Cada tienda ve fecha, stock, transito y ventas rezagadas; decide multiplicador de precio y cobertura de pedido. La local solo se ve a si misma; la coordinada recibe senales contemporaneas de las otras dos. Enfasis: observacion parcial, no estado completo.

## 4. Un almacen, tres tiendas (2:00)
El almacen tiene capacidad finita. Si la suma de pedidos lo supera, raciona en proporcion y el despacho llega al dia siguiente. Por eso una tienda puede danar a otra sin querer.

## 5. M5 real vs. simulado (1:30)
M5 solo aporta precios, calendario y ventas como demanda de referencia. Pedidos, existencias, faltantes, costes y elasticidad son supuestos del simulador. Precio historico significa multiplicador uno, no precio congelado.

## 6. Escalera (2:00)
Tronco comun tabular, Double DQN y PPO en ese orden. PBRS solo conserva el orden de acciones con su formula exacta; no ampara bonos heuristicos. Dyna es un modelo que genera transiciones: si ademas cambia la familia de RL, el contraste no aisla Dyna. Y retorno de entrenamiento sin descuento no es G0.

## 7. Portadilla II (0:20)
Segunda mitad: medir bien (frecuencia, severidad, retorno), el 586 a precio historico, el 090 que no repite, el reentreno con reglas y la demo en vivo.

## 8. Menos dias, mas unidades (3:30)
El grafico: T0 deja los quiebres en 116/122/93 frente a 1015 del ingenuo y 376/185/183 del egoista. En ventas, T0 vende 52133/52473/52008 con demanda comun de 57184; el ingenuo apenas 4844 y el egoista 41747/52590/52360. En retorno, T0 marca 79375/80339/78798 frente a -58924 del ingenuo y 49257/80869/79791 del egoista. Cumple 3/3 en tasa de al menos 30 por ciento frente a ambos mas retorno sobre el ingenuo, pero solo 1/3 supera al egoista en retorno. El ingenuo es la referencia principal.

## 9. 090 no repite + protocolo (3:00)
Misma receta en producto nuevo 090: T0 marca 641/541/645 dias con quiebre contra 26/12/18 del egoista y 886 del ingenuo; cero de tres tambien con precio dinamico. El 586 no se repite; y la ventana ya estaba inspeccionada, asi que es descriptivo. El reentreno restringido se rige por un criterio de servicio: menos quiebres, mas ventas, mas retorno que la ingenua y ninguna tienda peor. La ventana anual ya estaba inspeccionada, asi que es descriptivo y sus ventanas son disjuntas por dias.

## 10. Demo (3:00)
Abrir video.mp4 junto al PDF en el mismo ZIP. Tres filas por tres tiendas avanzando el mismo dia del 1 al 365; el color es unidades perdidas, no solo si hubo quiebre. El mapa de 14 dias y los acumulados separan incidencia, ventas y retorno. Solo T0, E y N.

## 11. Cierre (1:00)
Si decimos: frecuencia, severidad y retorno son tres cosas; 3/3 en tasa frente a ambos pero 1/3 en retorno frente al egoista; el 090 pide cautela. No decimos: nada fuera de estos tres brazos, sin extrapolar a tienda real, sin proclamas de convergencia. Gracias y preguntas.
